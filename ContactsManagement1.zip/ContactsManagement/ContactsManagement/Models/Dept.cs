﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactsManagement.Models
{
    public enum Dept
    {
        None,
        HR, 
        IT,
        Payroll
    }
}
