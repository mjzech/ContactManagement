﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactsManagement.Controllers
{
    public class DepartmentsController : Controller
    {
        public string List()
        {
            return "List() of Departments Controller";
        }

        public string Details()
        {
            return "Details() of Departments Controller";
        }
    }
}
